(function ($) {
	"use strict";

	$( document ).ready(
		function () {
			qodefFloatingSocialNetworks.init();
		}
	);

	var qodefFloatingSocialNetworks = {
		init: function () {
			this.holder = $( '#qodef-floating-social-networks' );

			if ( this.holder.length ) {
				this.holder.each(
					function () {
						var $thisHolder = $( this );

						qodefFloatingSocialNetworks.changeSkin( $thisHolder );
					}
				);
			}
		},
		changeSkin: function ( $holder ) {
			$holder.addClass( 'qodef--init' );

			var $skinElements = $( '.qodef-row-light-class' ),
				$skinSet      = false,
				$skinTrigger  = [];

			// Control skin
			var holderSkin = function () {
				if ( $skinElements.length ) {
					$skinElements.each(
						function ( $i ) {
							var $skinElement = $( this );

							if ( qodef.scroll + $holder.position().top >= $skinElement.offset().top && qodef.scroll + $holder.position().top <= $skinElement.offset().top + $skinElement.outerHeight() ) {
								  $skinTrigger[$i] = true;
							} else {
								$skinTrigger[$i] = false;
							}
						}
					);

					if ( jQuery.inArray( true, $skinTrigger ) != -1 ) {
						if ( ! $skinSet ) {
							$holder.addClass( 'qodef--light' );
							$skinSet = true;
						}
					} else {
						if ( $skinSet ) {
							$holder.removeClass( 'qodef--light' );
							$skinSet = false;
						}
					}
				}
			}

			if ( $holder.length && $skinElements.length ) {
				$( window ).scroll(
					function () {
						holderSkin();
					}
				);
			}
		}
	};

})( jQuery );
