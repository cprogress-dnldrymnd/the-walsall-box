<?php

if ( ! function_exists( 'esmee_core_add_floating_social_networks_single_meta_box' ) ) {
	/**
	 * Function that add general meta box options for this module
	 *
	 * @param object $page
	 */
	function esmee_core_add_floating_social_networks_single_meta_box( $page ) {

		if ( $page ) {

			$floating_social_networks_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-floating-social-networks',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'Floating Social Networks Settings', 'esmee-core' ),
					'description' => esc_html__( 'Floating Social Networks Settings', 'esmee-core' ),
				)
			);

			$floating_social_networks_tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_enable_floating_social_networks',
					'title'       => esc_html__( 'Enable Floating Social Networks', 'esmee-core' ),
					'description' => esc_html__( 'Use this option to enable/disable Floating Social Networks', 'esmee-core' ),
					'options'     => esmee_core_get_select_type_options_pool( 'no_yes' ),
				)
			);

			$floating_social_networks_tab->add_field_element(
				array(
					'field_type'    => 'select',
					'options'     => esmee_core_get_select_type_options_pool( 'no_yes' ),
					'name'          => 'qodef_enable_floating_social_networks_light_skin',
					'title'         => esc_html__( 'Use Light Skin', 'esmee-core' ),
					'default_value' => 'no',
					'dependency' => array(
						'show' => array(
							'qodef_enable_floating_social_networks' => array(
								'values'        => 'yes',
								'default_value' => ''
							)
						)
					)
				)
			);

			// Hook to include additional options after module options
			do_action( 'esmee_core_action_after_page_floating_social_networks_meta_box_map', $floating_social_networks_tab );
		}
	}

	add_action( 'esmee_core_action_after_general_meta_box_map', 'esmee_core_add_floating_social_networks_single_meta_box' );
}
