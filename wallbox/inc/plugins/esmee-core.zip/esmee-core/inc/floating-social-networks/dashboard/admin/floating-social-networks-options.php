<?php

if ( ! function_exists( 'esmee_core_add_floating_social_networks_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function esmee_core_add_floating_social_networks_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'       => ESMEE_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'floating-social-networks',
				'icon'        => 'fa fa-envelope',
				'title'       => esc_html__( 'Floating Social Networks', 'esmee-core' ),
				'description' => esc_html__( 'Global Floating Social Networks Options', 'esmee-core' ),
			)
		);

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_floating_social_networks',
					'title'         => esc_html__( 'Enable Floating Social Networks', 'esmee-core' ),
					'description'   => esc_html__( 'Use this option to enable/disable Floating Social Networks', 'esmee-core' ),
					'default_value' => 'no',
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_floating_social_networks_light_skin',
					'title'         => esc_html__( 'Use Light Skin', 'esmee-core' ),
					'default_value' => 'no',
					'dependency'    => array(
						'show' => array(
							'qodef_enable_floating_social_networks' => array(
								'values'        => 'yes',
								'default_value' => '',
							),
						),
					),
				)
			);

			$floating_social_networks_section = $page->add_section_element(
				array(
					'field_type' => 'yesno',
					'name'       => 'qodef_floating_social_networks_section',
					'title'      => esc_html__( 'Add Floating Social Networks', 'esmee-core' ),
					'dependency' => array(
						'show' => array(
							'qodef_enable_floating_social_networks' => array(
								'values'        => 'yes',
								'default_value' => '',
							),
						),
					),
				)
			);
			/*$floating_social_networks_section->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_search_icon_pack',
					'title'         => esc_html__( 'Icon Pack', 'esmee-core' ),
					'options'       => qode_framework_icons()->get_icon_packs(
						array(
							'linea-icons',
							'dripicons',
							'simple-line-icons',
						)
					),
					'default_value' => 'font-awesome',
				)
			);*/

			$page_repeater = $floating_social_networks_section->add_repeater_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_add_new_floating_social_network',
					'button_text' => esc_html__( 'Add New Floating Social Network', 'esmee-core' ),
				)
			);

			$page_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_floating_social_network_text',
					'title'      => esc_html__( 'Floating Social Network Text', 'esmee-core' ),
				)
			);

			$page_repeater->add_field_element(
				array(
					'field_type' => 'iconpack',
					'name'       => 'qodef_floating_social_icon',
					'title'      => esc_html__( 'Icon', 'masterds-core' ),
				)
			);
			$page_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_floating_social_network_link',
					'title'      => esc_html__( 'Floating Social Network Link', 'esmee-core' ),
				)
			);

			// Hook to include additional options after module options
			do_action( 'esmee_core_action_after_floating_social_networks_options_map', $floating_social_networks_section );
		}
	}

	add_action( 'esmee_core_action_default_options_init', 'esmee_core_add_floating_social_networks_options', esmee_core_get_admin_options_map_position( 'floating-social-networks' ) );
}
