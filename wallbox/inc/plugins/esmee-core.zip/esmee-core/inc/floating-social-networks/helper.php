<?php

if ( ! function_exists( 'esmee_core_get_floating_social_networks' ) ) {
	/**
	 * Loads Floating Social Networks HTML
	 */
	function esmee_core_get_floating_social_networks() {
		if ( esmee_core_get_post_value_through_levels( 'qodef_enable_floating_social_networks' ) === 'yes' ) {
			esmee_core_load_floating_social_networks_template();
		}
	}

	// Get Floating Social Networks HTML
	add_action( 'esmee_action_before_wrapper_close_tag', 'esmee_core_get_floating_social_networks' );
}

if ( ! function_exists( 'esmee_core_load_floating_social_networks_template' ) ) {
	/**
	 * Loads HTML template with params
	 */
	function esmee_core_load_floating_social_networks_template() {
		$params               = array();
		$params['networks']   = esmee_core_get_option_value( 'admin', 'qodef_add_new_floating_social_network' );
		$params['light_skin'] = 'qodef-light-skin-' . esmee_core_get_post_value_through_levels( 'qodef_enable_floating_social_networks_light_skin' );

		echo esmee_core_get_template_part( 'floating-social-networks', 'templates/floating-social-networks', '', $params );
	}
}
