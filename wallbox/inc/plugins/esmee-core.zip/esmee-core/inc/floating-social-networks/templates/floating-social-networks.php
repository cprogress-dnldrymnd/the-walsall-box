<div id="qodef-floating-social-networks" <?php qode_framework_class_attribute( $light_skin ); ?>>
	<?php

	$framework_icons = QodeFrameworkIcons::get_instance();

	if ( isset( $params['networks'] ) && ! empty( $params['networks'] ) && is_array( $params['networks'] ) ) {
		foreach ( $params['networks'] as $single_network ) {
			$social_icon_pack = $single_network['qodef_floating_social_icon'];
			$social_icon_name = $framework_icons->get_formatted_icon_field_name( 'qodef_floating_social_icon', $social_icon_pack, '-' );
			$social_icon      = $single_network[ $social_icon_name ];
			?>
			<a href="
			<?php
			if ( isset( $single_network['qodef_floating_social_network_link'] ) ) {
				echo esc_attr( $single_network['qodef_floating_social_network_link'] );
			} else {
				echo '#';
			}
			?>
			" target="_blank">
				<div class="qodef-floating-text">
					<?php
					if ( isset( $single_network['qodef_floating_social_network_text'] ) ) {
					    echo '<span class="qodef-m-text">';
						echo esc_attr( $single_network['qodef_floating_social_network_text'] );
						echo '</span>';
						echo qode_framework_wp_kses_html( 'html', $framework_icons->render_icon( $social_icon, $social_icon_pack ) );
					}
					?>
				</div>
			</a>
			<?php
		}
	};
	?>
</div>
