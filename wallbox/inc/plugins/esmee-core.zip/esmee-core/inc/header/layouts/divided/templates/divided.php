<div class="qodef-divided-header-left-wrapper">
	<?php
	// Include widget area two
	esmee_core_get_header_widget_area( 'two' );

	// Include divided left navigation
	esmee_core_template_part( 'header/layouts/divided', 'templates/parts/left-navigation' );
	?>
</div>
<?php
// Include logo
esmee_core_get_header_logo_image();
?>
<div class="qodef-divided-header-right-wrapper">
	<?php

	// Include widget area one
	esmee_core_get_header_widget_area();
	?>
</div>
