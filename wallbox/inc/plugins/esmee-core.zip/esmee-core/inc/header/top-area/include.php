<?php

include_once ESMEE_CORE_INC_PATH . '/header/top-area/class-esmeecore-top-area.php';
include_once ESMEE_CORE_INC_PATH . '/header/top-area/helper.php';

foreach ( glob( ESMEE_CORE_INC_PATH . '/header/top-area/dashboard/*/*.php' ) as $dashboard ) {
	include_once $dashboard;
}
