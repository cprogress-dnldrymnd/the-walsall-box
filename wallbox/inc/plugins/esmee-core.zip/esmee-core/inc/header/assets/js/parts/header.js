(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefHeaderScrollAppearance.init();
			qodefInput.init();
		}
	);

	var qodefHeaderScrollAppearance = {
		appearanceType: function () {
			return qodefCore.body.attr( 'class' ).indexOf( 'qodef-header-appearance--' ) !== -1 ? qodefCore.body.attr( 'class' ).match( /qodef-header-appearance--([\w]+)/ )[1] : '';
		},
		init: function () {
			var appearanceType = this.appearanceType();

			if ( appearanceType !== '' && appearanceType !== 'none' ) {
				qodefCore[appearanceType + 'HeaderAppearance']();
			}
		}
	};
	var qodefInput = {
		init: function () {
			var $holder = $('header .qodef-search-form, header .qodef-woo-product-search, header .wp-block-search');

			if ($holder.length) {
				$holder.each(function () {
					var $this = $(this);
					var $input = $this.find('input');
					var $button = $this.find('button');

					$(document).click(function(e) {
						if ($this.hasClass('qodef--opened')) {
							if( !($(e.target).closest($this).length > 0 )) {
								$this.removeClass('qodef--opened');
							}
						}
					});

					$this.on('click', function (e) {
						if ($this.hasClass('qodef--opened') && $input.val() !== '') {
							e.submit();
						}

						setTimeout(function () {
							$input.focus();
						}, 300);

						$this.addClass('qodef--opened');
						e.preventDefault();
					});
				});
			}
		}
	}

})( jQuery );
