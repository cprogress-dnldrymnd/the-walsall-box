<?php
$post_id       = get_the_ID();
$is_enabled    = esmee_core_get_post_value_through_levels( 'qodef_blog_single_enable_related_posts' );
$related_posts = esmee_core_get_custom_post_type_related_posts( $post_id, esmee_core_get_blog_single_post_taxonomies( $post_id ) );

if ( 'yes' === $is_enabled && ! empty( $related_posts ) && class_exists( 'EsmeeCore_Blog_List_Shortcode' ) ) { ?>
	<div id="qodef-related-posts">
		<h3 class="qodef-m-title"><?php esc_html_e( 'Related Posts', 'esmee-core' ); ?></h3>
		<?php
		$params = apply_filters(
			'esmee_core_filter_blog_single_related_posts_params',
			array(
				'custom_class'        => 'qodef--no-bottom-space',
				'columns'             => '3',
				'posts_per_page'      => 3,
				'additional_params'   => 'id',
				'layout'              => 'standard',
				'post_ids'            => $related_posts['items'],
				'title_tag'           => 'h3',
				'media_only_image'    => 'yes',
				'excerpt_length'      => '60',
				'images_proportion'   => 'custom',
				'custom_image_width'  => '300px',
				'custom_image_height' => '415px',
			)
		);

		echo EsmeeCore_Blog_List_Shortcode::call_shortcode( $params );
		?>
	</div>
<?php } ?>
