<?php

include_once ESMEE_CORE_INC_PATH . '/blog/shortcodes/blog-list/class-esmeecore-blog-list-shortcode.php';

foreach ( glob( ESMEE_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
