<?php

if ( ! function_exists( 'esmee_core_add_blog_list_variation_metro' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function esmee_core_add_blog_list_variation_metro( $variations ) {
		$variations['metro'] = esc_html__( 'Metro', 'esmee-core' );

		return $variations;
	}

	add_filter( 'esmee_core_filter_blog_list_layouts', 'esmee_core_add_blog_list_variation_metro' );
}
