<?php

if ( ! function_exists( 'esmee_core_add_blog_list_variation_simple' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function esmee_core_add_blog_list_variation_simple( $variations ) {
		$variations['simple'] = esc_html__( 'Simple', 'esmee-core' );

		return $variations;
	}

	add_filter( 'esmee_core_filter_blog_list_layouts', 'esmee_core_add_blog_list_variation_simple' );
}
