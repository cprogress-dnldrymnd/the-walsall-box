<?php

if ($query_result->have_posts()) {
    while ($query_result->have_posts()) :
        $query_result->the_post();
        $media_only_image = esmee_core_get_post_value_through_levels('media_only_image');

        $params['image_dimension'] = $this_shortcode->get_list_item_image_dimension($params);
        $params['item_classes'] = $this_shortcode->get_item_classes($params);

        $post_format = get_post_format();
        if ($media_only_image == 'yes') { //override settings for related post
            $post_format = 'only-image';
        }

        esmee_core_list_sc_template_part('blog/shortcodes/blog-list', 'layouts/' . $layout, $post_format, $params);
    endwhile; // End of the loop.
} else {
    // Include global posts not found
    esmee_core_theme_template_part('content', 'templates/parts/posts-not-found');
}

wp_reset_postdata();
