(function ( $ ) {
	'use strict';

	var shortcode = 'esmee_core_blog_list';

	qodefCore.shortcodes[shortcode] = {};

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}

	$( window ).on(
		'load',
		() => {
			qodefBlogList.init();
		}
	);

	var qodefBlogList = {
		init () {
			this.blog = $('.qodef-blog');

			if ( this.blog.length ) {
				this.blog.each(
					( index, element ) => {
						const $thisBlogList = $( element );

						if ( $thisBlogList.hasClass('qodef-hover-animation--yes') ) {
							qodefBlogList.linkHover( $thisBlogList );
						}

						if ( $thisBlogList.hasClass('qodef-appear-animation--yes') ) {
							qodefBlogList.appearAnimation( $thisBlogList );
						}
					}
				);
			}
		},
		linkHover ( $holder ) {
			const $items = $holder.find('.qodef-blog-item');

			$items.each(
				( index, element ) => {
					const $thisItem = $( element ),
						$itemMedia = $thisItem.find('.qodef-e-media-image'),
						$titleLink = $thisItem.find('.qodef-e-title-link');

					if ( $itemMedia.length ) {
						$itemMedia.on(
							'mouseenter',
							() => {
								$thisItem.addClass('qodef--active');
							}
						);

						$itemMedia.on(
							'mouseleave',
							() => {
								$thisItem.removeClass('qodef--active');
							}
						);
					}

					if ( $titleLink.length ) {
						$titleLink.on(
							'mouseenter',
							() => {
								$thisItem.addClass('qodef--active');
							}
						);

						$titleLink.on(
							'mouseleave',
							() => {
								$thisItem.removeClass('qodef--active');
							}
						);
					}
				}
			);
		},
		appearAnimation ( $holder ) {
			qodefCore.qodefIsInViewport.check(
				$holder,
				() => {
					$holder.addClass( 'qodef--appeared' );
				}
			);
		}
	};

	qodefCore.shortcodes[shortcode].qodefBlogList      = qodefBlogList;
	qodefCore.shortcodes[shortcode].qodefResizeIframes = qodef.qodefResizeIframes;

})( jQuery );
