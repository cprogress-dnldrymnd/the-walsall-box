<?php

if ( ! function_exists( 'esmee_core_add_blog_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function esmee_core_add_blog_list_widget( $widgets ) {
		$widgets[] = 'EsmeeCore_Blog_List_Widget';

		return $widgets;
	}

	add_filter( 'esmee_core_filter_register_widgets', 'esmee_core_add_blog_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class EsmeeCore_Blog_List_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'widget_title',
					'title'      => esc_html__( 'Title', 'esmee-core' ),
				)
			);
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'esmee_core_blog_list',
				)
			);

			if ( $widget_mapped ) {
				$this->set_base( 'esmee_core_blog_list' );
				$this->set_name( esc_html__( 'Esmee Blog List', 'esmee-core' ) );
				$this->set_description( esc_html__( 'Display a list of blog posts', 'esmee-core' ) );
			}
		}

		public function render( $atts ) {
			$atts['is_widget_element'] = 'yes';

			echo EsmeeCore_Blog_List_Shortcode::call_shortcode( $atts ); // XSS OK
		}
	}
}
