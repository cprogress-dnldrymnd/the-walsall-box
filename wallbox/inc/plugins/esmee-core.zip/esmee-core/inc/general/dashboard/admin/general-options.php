<?php

if ( ! function_exists( 'esmee_core_add_general_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function esmee_core_add_general_options( $page ) {

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_main_color',
					'title'       => esc_html__( 'Main Color', 'esmee-core' ),
					'description' => esc_html__( 'Choose the most dominant theme color', 'esmee-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_page_background_color',
					'title'       => esc_html__( 'Page Background Color', 'esmee-core' ),
					'description' => esc_html__( 'Set background color', 'esmee-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_page_background_image',
					'title'       => esc_html__( 'Page Background Image', 'esmee-core' ),
					'description' => esc_html__( 'Set background image', 'esmee-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_repeat',
					'title'       => esc_html__( 'Page Background Image Repeat', 'esmee-core' ),
					'description' => esc_html__( 'Set background image repeat', 'esmee-core' ),
					'options'     => array(
						''          => esc_html__( 'Default', 'esmee-core' ),
						'no-repeat' => esc_html__( 'No Repeat', 'esmee-core' ),
						'repeat'    => esc_html__( 'Repeat', 'esmee-core' ),
						'repeat-x'  => esc_html__( 'Repeat-x', 'esmee-core' ),
						'repeat-y'  => esc_html__( 'Repeat-y', 'esmee-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_size',
					'title'       => esc_html__( 'Page Background Image Size', 'esmee-core' ),
					'description' => esc_html__( 'Set background image size', 'esmee-core' ),
					'options'     => array(
						''        => esc_html__( 'Default', 'esmee-core' ),
						'contain' => esc_html__( 'Contain', 'esmee-core' ),
						'cover'   => esc_html__( 'Cover', 'esmee-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_attachment',
					'title'       => esc_html__( 'Page Background Image Attachment', 'esmee-core' ),
					'description' => esc_html__( 'Set background image attachment', 'esmee-core' ),
					'options'     => array(
						''       => esc_html__( 'Default', 'esmee-core' ),
						'fixed'  => esc_html__( 'Fixed', 'esmee-core' ),
						'scroll' => esc_html__( 'Scroll', 'esmee-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding',
					'title'       => esc_html__( 'Page Content Padding', 'esmee-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'esmee-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding_mobile',
					'title'       => esc_html__( 'Page Content Padding Mobile', 'esmee-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content on mobile screens (1024px and below) in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'esmee-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_boxed',
					'title'         => esc_html__( 'Boxed Layout', 'esmee-core' ),
					'description'   => esc_html__( 'Set boxed layout', 'esmee-core' ),
					'default_value' => 'no',
				)
			);

			$boxed_section = $page->add_section_element(
				array(
					'name'       => 'qodef_boxed_section',
					'title'      => esc_html__( 'Boxed Layout Section', 'esmee-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_boxed' => array(
								'values'        => 'no',
								'default_value' => '',
							),
						),
					),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_boxed_background_color',
					'title'       => esc_html__( 'Boxed Background Color', 'esmee-core' ),
					'description' => esc_html__( 'Set boxed background color', 'esmee-core' ),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_boxed_background_pattern',
					'title'       => esc_html__( 'Boxed Background Pattern', 'esmee-core' ),
					'description' => esc_html__( 'Set boxed background pattern', 'esmee-core' ),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_boxed_background_pattern_behavior',
					'title'       => esc_html__( 'Boxed Background Pattern Behavior', 'esmee-core' ),
					'description' => esc_html__( 'Set boxed background pattern behavior', 'esmee-core' ),
					'options'     => array(
						'fixed'  => esc_html__( 'Fixed', 'esmee-core' ),
						'scroll' => esc_html__( 'Scroll', 'esmee-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_passepartout',
					'title'         => esc_html__( 'Passepartout', 'esmee-core' ),
					'description'   => esc_html__( 'Enabling this option will display a passepartout around website content', 'esmee-core' ),
					'default_value' => 'no',
				)
			);

			$passepartout_section = $page->add_section_element(
				array(
					'name'       => 'qodef_passepartout_section',
					'title'      => esc_html__( 'Passepartout Section', 'esmee-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_passepartout' => array(
								'values'        => 'no',
								'default_value' => '',
							),
						),
					),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_passepartout_color',
					'title'       => esc_html__( 'Passepartout Color', 'esmee-core' ),
					'description' => esc_html__( 'Choose background color for passepartout', 'esmee-core' ),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_passepartout_image',
					'title'       => esc_html__( 'Passepartout Background Image', 'esmee-core' ),
					'description' => esc_html__( 'Set background image for passepartout', 'esmee-core' ),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size',
					'title'       => esc_html__( 'Passepartout Size', 'esmee-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout', 'esmee-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'esmee-core' ),
					),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size_responsive',
					'title'       => esc_html__( 'Passepartout Responsive Size', 'esmee-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout for smaller screens (1024px and below)', 'esmee-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'esmee-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_content_width',
					'title'         => esc_html__( 'Initial Width of Content', 'esmee-core' ),
					'description'   => esc_html__( 'Choose the initial width of content which is in grid (applies to pages set to "Default Template" and rows set to "In Grid")', 'esmee-core' ),
					'options'       => esmee_core_get_select_type_options_pool( 'content_width', false ),
					'default_value' => '1100',
				)
			);

			// Hook to include additional options after module options
			do_action( 'esmee_core_action_after_general_options_map', $page );

			$page->add_field_element(
				array(
					'field_type'  => 'textarea',
					'name'        => 'qodef_custom_js',
					'title'       => esc_html__( 'Custom JS', 'esmee-core' ),
					'description' => esc_html__( 'Enter your custom JavaScript here', 'esmee-core' ),
				)
			);
		}
	}

	add_action( 'esmee_core_action_default_options_init', 'esmee_core_add_general_options', esmee_core_get_admin_options_map_position( 'general' ) );
}
