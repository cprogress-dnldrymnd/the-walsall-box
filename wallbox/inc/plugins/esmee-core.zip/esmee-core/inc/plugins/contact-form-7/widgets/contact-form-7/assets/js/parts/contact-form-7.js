(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			$( ".qodef-email-with-check input" ).keyup(
				function(){
					var email  = $( this ).val();
					var parent = $( this ).parents( '.qodef-email-with-check ' );

					if (isEmail( email )) {
						parent.removeClass( "qodef-email-incorrect" ).addClass( "qodef-email-correct" );
					} else if ( '' === email) {
						parent.removeClass( "qodef-email-correct qodef-email-incorrect" );
					} else {
						parent.removeClass( "qodef-email-correct" ).addClass( "qodef-email-incorrect" );
					}
				}
			);
		}
	);
	function isEmail(email) {
		var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		return regex.test( email );
	}
})( jQuery );
