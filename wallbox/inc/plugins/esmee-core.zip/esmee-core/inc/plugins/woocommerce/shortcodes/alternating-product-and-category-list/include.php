<?php

include_once ESMEE_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/alternating-product-and-category-list/class-esmeecore-alternating-product-and-category-list-shortcode.php';

foreach ( glob( ESMEE_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/alternating-product-and-category-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
