<li <?php wc_product_cat_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-woo-category-image">
			<?php esmee_core_template_part( 'plugins/woocommerce/shortcodes/product-category-list', 'templates/post-info/image', '', $params ); ?>
			<a href="<?php echo get_term_link( $category_slug, 'product_cat' ); ?>"></a>
		</div>
		<div class="qodef-woo-category-image-below-content">
			<?php esmee_core_template_part( 'plugins/woocommerce/shortcodes/product-category-list', 'templates/post-info/title', '', $params ); ?>
			<?php esmee_core_template_part( 'plugins/woocommerce/shortcodes/product-category-list', 'templates/post-info/description', '', $params ); ?>
		</div>
	</div>
</li>
