<?php if ( !empty( $category_description ) ) { ?>
	<p class="woocommerce-loop-category__description">
		<?php echo esc_html( $category_description ); ?>
	</p>
<?php }