<a itemprop="url" class="qodef-m-opener" href="<?php echo esc_url( wc_get_cart_url() ); ?>">
	<span class="qodef-m-svg-icon"><?php echo esmee_core_get_svg_icon( 'cart' ); ?></span>
	<h6 class="qodef-m-opener-icon"><?php echo esc_attr__( 'Cart', 'esmee-core' ); ?></h6>
	<h6 class="qodef-m-opener-count">(<?php echo WC()->cart->cart_contents_count; ?>)</h6>
</a>
