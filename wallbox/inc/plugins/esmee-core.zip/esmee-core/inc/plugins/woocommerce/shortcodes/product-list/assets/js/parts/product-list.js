(function ( $ ) {
	'use strict';

	var shortcode = 'esmee_core_product_list';

	qodefCore.shortcodes[shortcode] = {};

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}

	$( window ).on(
		'load',
		() => {
			qodefProductList.init();
		}
	);

	var qodefProductList = {
		init () {
			this.shortcode = $('.qodef-woo-product-list');

			if ( this.shortcode.length ) {
				this.shortcode.each(
					( index, element ) => {
						const $thisShortcode = $( element );

						if ( $thisShortcode.hasClass('qodef-appear-animation--yes') ) {
							qodefProductList.appearAnimation( $thisShortcode );
						}
					}
				);
			}
		},
		appearAnimation ( $holder ) {
			qodefCore.qodefIsInViewport.check(
				$holder,
				() => {
					const $items = $holder.find('.qodef-e');

					if ( $items.length ) {
						$items.each(
							( index, element ) => {
								const $thisItem = $( element );

								setTimeout(
									() => {
										$thisItem.addClass('qodef--appeared');
									}, index * 175
								);
							}
						);
					}
				}
			);
		}
	};

	qodefCore.shortcodes[shortcode].qodefProductList = qodefProductList;

})( jQuery );
