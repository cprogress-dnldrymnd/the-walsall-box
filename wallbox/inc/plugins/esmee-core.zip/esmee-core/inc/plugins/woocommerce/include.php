<?php

include_once ESMEE_CORE_PLUGINS_PATH . '/woocommerce/class-esmeecore-woocommerce.php';
