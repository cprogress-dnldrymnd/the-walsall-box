<?php

if ( ! function_exists( 'esmee_core_add_product_category_list_variation_info_on_image_centered' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function esmee_core_add_product_category_list_variation_info_on_image_centered( $variations ) {
		$variations['info-on-image-centered'] = esc_html__( 'Info On Image Centered', 'esmee-core' );

		return $variations;
	}

	add_filter( 'esmee_core_filter_product_category_list_layouts', 'esmee_core_add_product_category_list_variation_info_on_image_centered' );
}
