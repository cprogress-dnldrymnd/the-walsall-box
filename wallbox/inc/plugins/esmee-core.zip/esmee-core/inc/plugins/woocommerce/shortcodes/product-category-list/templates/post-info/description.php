<?php if ( !empty( $category_description ) ) { ?>
	<h5 class="woocommerce-loop-category__description">
		<?php echo esc_html( $category_description ); ?>
	</h5>
<?php }
