(function ( $ ) {
	'use strict';

	var shortcode = 'esmee_core_alternating_product_and_category_list';

	qodefCore.shortcodes[shortcode] = {};

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}

	$( window ).on(
		'load',
		() => {
			qodefAlternatingProductAndCategoryList.init();
		}
	);

	var qodefAlternatingProductAndCategoryList = {
		init () {
			this.shortcode = $('.qodef-woo-alternating-product-and-category-list');

			if ( this.shortcode.length ) {
				this.shortcode.each(
					( index, element ) => {
						const $thisShortcode = $( element );

						if ( $thisShortcode.hasClass('qodef-appear-animation--yes') ) {
							qodefAlternatingProductAndCategoryList.appearAnimation( $thisShortcode );
						}
					}
				);
			}
		},
		appearAnimation ( $holder ) {
			qodefCore.qodefIsInViewport.check(
				$holder,
				() => {
					const $productItems  = $holder.find('.product');
					const $categoryItems = $holder.find('.product-category');

					if ( $productItems.length ) {
						$productItems.each(
							( index, element ) => {
								const $thisItem = $( element );

								setTimeout(
									() => {
										$thisItem.addClass('qodef--appeared');
									}, index * 160 + 160
								);
							}
						);
					}

					if ( $categoryItems.length ) {
						$categoryItems.each(
							( index, element ) => {
								const $thisItem = $( element );

								setTimeout(
									() => {
										$thisItem.addClass('qodef--appeared');
									}, index * 160
								);
							}
						);
					}
				}
			);
		}
	};

	qodefCore.shortcodes[shortcode].qodefAlternatingProductAndCategoryList = qodefAlternatingProductAndCategoryList;

})( jQuery );
