<li <?php wc_product_cat_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-woo-category-image">
			<?php esmee_core_template_part( 'plugins/woocommerce/shortcodes/product-category-list', 'templates/post-info/image', '', $params ); ?>
			<div class="qodef-woo-category-image-inner">
				<?php esmee_core_template_part( 'plugins/woocommerce/shortcodes/product-category-list', 'templates/post-info/title', '', $params ); ?>
			</div>
			<a href="<?php echo get_term_link( $category_slug, 'product_cat' ); ?>"></a>
		</div>
	</div>
</li>
