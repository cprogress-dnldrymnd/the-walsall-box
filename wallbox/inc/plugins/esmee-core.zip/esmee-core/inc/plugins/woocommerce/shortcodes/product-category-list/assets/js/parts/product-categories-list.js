(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.esmee_core_product_category_list = {};

	$( window ).on(
		'load',
		() => {
			qodefProductCategoriesList.init();
		}
	);

	var qodefProductCategoriesList = {
		init () {
			this.shortcode = $('.qodef-woo-product-category-list:not(.qodef-woo-alternating-product-and-category-list)');

			if ( this.shortcode.length ) {
				this.shortcode.each(
					( index, element ) => {
						const $thisShortcode = $( element );

						if ( $thisShortcode.hasClass('qodef-appear-animation--yes') ) {
							qodefProductCategoriesList.appearAnimation( $thisShortcode );
						}
					}
				);
			}
		},
		appearAnimation ( $holder ) {
			const delay = $holder.data('appear-delay');

			qodefCore.qodefIsInViewport.check(
				$holder,
				() => {
					const $items = $holder.find('.qodef-e');

					if ( $items.length ) {
						$items.each(
							( index, element ) => {
								const $thisItem = $( element );

								setTimeout(
									() => {
										$thisItem.addClass('qodef--appeared');
									}, index * 175 + delay
								);
							}
						);
					}
				}
			);
		}
	};

	qodefCore.shortcodes.esmee_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.esmee_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
