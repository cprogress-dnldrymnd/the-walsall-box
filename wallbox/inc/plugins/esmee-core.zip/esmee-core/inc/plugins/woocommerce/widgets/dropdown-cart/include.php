<?php

include_once ESMEE_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-esmeecore-woocommerce-dropdown-cart-widget.php';
