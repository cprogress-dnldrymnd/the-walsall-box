<?php if ( class_exists( 'EsmeeCore_Social_Share_Shortcode' ) ) { ?>
	<div class="qodef-woo-product-social-share">
		<?php
		$params          = array();
		$params['title'] = esc_html__( 'Share:', 'esmee-core' );

		echo EsmeeCore_Social_Share_Shortcode::call_shortcode( $params );
		?>
	</div>
<?php } ?>
