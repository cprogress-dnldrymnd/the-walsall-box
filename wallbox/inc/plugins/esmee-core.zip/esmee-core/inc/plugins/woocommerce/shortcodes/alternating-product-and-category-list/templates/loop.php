<?php
if ( $product_query->have_posts() || count( $taxonomy_items ) ) {
	$counter = 0;
	while ( $product_query->have_posts() ) :
		$product_query->the_post();

		$params['image_dimension'] = $this_shortcode->get_list_item_image_dimension( $params );
		$params['item_classes']    = $this_shortcode->get_item_classes( $params );

		esmee_core_template_part( 'plugins/woocommerce/shortcodes/alternating-product-and-category-list', 'templates/product', '', $params );
		if ( isset ( $taxonomy_items[ $counter ] ) ) {
			$params['category_slug']        = $taxonomy_items[ $counter ]->slug;
			$params['category_name']        = $taxonomy_items[ $counter ]->name;
			$params['category_id']          = $taxonomy_items[ $counter ]->term_id;
			$params['category_description'] = $taxonomy_items[ $counter ]->description;
			$params['image_dimension']      = $this_shortcode->get_category_image_dimension( $params );

			esmee_core_template_part( 'plugins/woocommerce/shortcodes/alternating-product-and-category-list', 'templates/category', '', $params );
		}
		$counter++;
	endwhile; // End of the loop.
	if ( $counter < count( $taxonomy_items ) ) {
		for ( $i = $counter; $i < count( $taxonomy_items ); $i++ ) {
			$params['category_slug']        = $taxonomy_items[ $i ]->slug;
			$params['category_name']        = $taxonomy_items[ $i ]->name;
			$params['category_id']          = $taxonomy_items[ $i ]->term_id;
			$params['category_description'] = $taxonomy_items[ $i ]->description;
			$params['image_dimension']      = $this_shortcode->get_category_image_dimension( $params );

			esmee_core_template_part( 'plugins/woocommerce/shortcodes/alternating-product-and-category-list', 'templates/category', '', $params );
		}
	}
} else {
	// Include global posts not found
	esmee_core_theme_template_part( 'content', 'templates/parts/posts-not-found' );
}

wp_reset_postdata();
