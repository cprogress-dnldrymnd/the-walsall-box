<?php

include_once ESMEE_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-category-list/variations/info-on-image/info-on-image.php';
