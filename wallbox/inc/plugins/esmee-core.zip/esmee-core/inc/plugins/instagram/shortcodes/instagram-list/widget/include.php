<?php

include_once ESMEE_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-esmeecore-instagram-list-widget.php';
