<?php

include_once ESMEE_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-esmeecore-instagram-list-shortcode.php';
