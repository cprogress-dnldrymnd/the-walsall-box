<?php

include_once ESMEE_CORE_INC_PATH . '/icons/font-awesome/class-esmeecore-font-awesome-pack.php';
