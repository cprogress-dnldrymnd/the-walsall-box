<?php

include_once ESMEE_CORE_INC_PATH . '/icons/elegant-icons/class-esmeecore-elegant-icons-pack.php';
