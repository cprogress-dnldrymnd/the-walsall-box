<?php

include_once ESMEE_CORE_INC_PATH . '/footer/helper.php';
include_once ESMEE_CORE_INC_PATH . '/footer/dashboard/admin/footer-options.php';
include_once ESMEE_CORE_INC_PATH . '/footer/dashboard/meta-box/footer-meta-box.php';
