<?php

include_once ESMEE_CORE_INC_PATH . '/background-text/helper.php';
