<?php if ( $has_custom_fractions ) { ?>
	<div class="swiper-custom-fractions swiper-pagination-fraction">
		<span class="swiper-active">1</span> / <span
			class="swiper-total"></span>
	</div>
<?php } ?>