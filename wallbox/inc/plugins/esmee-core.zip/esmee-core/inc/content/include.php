<?php

include_once ESMEE_CORE_INC_PATH . '/content/helper.php';
